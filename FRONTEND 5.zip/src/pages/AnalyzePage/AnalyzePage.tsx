import { useState } from 'react';
import LogInput from '../../components/LogInput/LogInput';
import AnalysisResult from '../../components/AnalysisResult/AnalysisResult';
import Loader from '../../components/common/Loader/Loader';
import ErrorMessage from '../../components/common/ErrorMessage/ErrorMessage';
import { analyzeLog } from '../../services/analysisService';
import { AnalyzeResponse } from '../../types';
import './AnalyzePage.css';

type PageState = 'idle' | 'loading' | 'success' | 'error';

export default function AnalyzePage() {
  const [state, setState] = useState<PageState>('idle');
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [error, setError] = useState('');

  const handleSubmit = async (logText: string, format?: string) => {
    setState('loading');
    setError('');
    setResult(null);

    try {
      const response = await analyzeLog({
        log_text: logText,
        input_format: format,
      });
      setResult(response);
      setState('success');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
      setState('error');
    }
  };

  return (
    <div className="analyze-page">
      <LogInput onSubmit={handleSubmit} isLoading={state === 'loading'} />

      {state === 'loading' && <Loader message="Analyzing logs... This may take up to a minute." />}

      {state === 'error' && (
        <ErrorMessage message={error} onRetry={() => setState('idle')} />
      )}

      {state === 'success' && result && (
        <div className="results-container">
          <div className="results-header">
            <h3>{result.message}</h3>
            <span className="results-meta">
              {result.entry_count} entries parsed | Format: {result.input_format}
            </span>
          </div>

          {result.anomalies.length === 0 && (
            <div className="no-anomalies">
              <p>No anomalies were detected in the provided log segment.</p>
            </div>
          )}

          {result.anomalies.map((anomaly) => {
            const relatedTypes = result.anomalies
              .filter((a) => a.anomaly_id !== anomaly.anomaly_id)
              .map((a) => a.anomaly_type)
              .filter((t, i, arr) => arr.indexOf(t) === i);

            return (
              <AnalysisResult
                key={anomaly.anomaly_id}
                anomaly={anomaly}
                sessionId={result.session_id}
                relatedTypes={relatedTypes.length > 0 ? relatedTypes : undefined}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
