import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import HistoryList from '../../components/HistoryList/HistoryList';
import HistoryDetail from '../../components/HistoryDetail/HistoryDetail';
import Loader from '../../components/common/Loader/Loader';
import ErrorMessage from '../../components/common/ErrorMessage/ErrorMessage';
import { getHistoryList, getHistoryDetail } from '../../services/historyService';
import { HistoryListItem, HistoryDetailResponse } from '../../types';
import './HistoryPage.css';

export default function HistoryPage() {
  const { sessionId } = useParams<{ sessionId?: string }>();
  const navigate = useNavigate();

  const [items, setItems] = useState<HistoryListItem[]>([]);
  const [detail, setDetail] = useState<HistoryDetailResponse | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (sessionId) {
      setLoading(true);
      setError('');
      getHistoryDetail(sessionId)
        .then(setDetail)
        .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load detail'))
        .finally(() => setLoading(false));
    } else {
      setDetail(null);
      setLoading(true);
      setError('');
      getHistoryList(page)
        .then((res) => {
          setItems(res.items);
          setTotalPages(res.total_pages);
        })
        .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load history'))
        .finally(() => setLoading(false));
    }
  }, [sessionId, page]);

  if (loading) return <div className="history-page"><Loader message="Loading..." /></div>;
  if (error) return <div className="history-page"><ErrorMessage message={error} onRetry={() => window.location.reload()} /></div>;

  if (sessionId && detail) {
    return (
      <div className="history-page">
        <HistoryDetail detail={detail} onBack={() => navigate('/history')} />
      </div>
    );
  }

  return (
    <div className="history-page">
      <h2>Analysis History</h2>
      <HistoryList
        items={items}
        onSelect={(id) => navigate(`/history/${id}`)}
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
      />
    </div>
  );
}
