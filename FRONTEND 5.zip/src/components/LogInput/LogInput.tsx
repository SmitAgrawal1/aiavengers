import { useState, useRef } from 'react';
import './LogInput.css';

interface LogInputProps {
  onSubmit: (logText: string, format?: string) => void;
  isLoading: boolean;
}

export default function LogInput({ onSubmit, isLoading }: LogInputProps) {
  const [logText, setLogText] = useState('');
  const [format, setFormat] = useState<string>('auto');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = () => {
    if (!logText.trim()) return;
    const selectedFormat = format === 'auto' ? undefined : format;
    onSubmit(logText, selectedFormat);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('File size exceeds 2 MB limit.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setLogText(content);
    };
    reader.readAsText(file);
  };

  return (
    <div className="log-input-container">
      <h2 className="log-input-title">Analyze Logs</h2>
      <p className="log-input-subtitle">
        Paste your log entries below or upload a file to detect anomalies and get explanations.
      </p>

      <textarea
        className="log-textarea"
        placeholder="Paste your log entries here...&#10;&#10;Supported formats:&#10;- Plain text (one entry per line)&#10;- JSON array of log objects"
        value={logText}
        onChange={(e) => setLogText(e.target.value)}
        rows={12}
        disabled={isLoading}
      />

      <div className="log-input-controls">
        <div className="log-input-left">
          <button
            className="upload-btn"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
          >
            Upload File
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,.txt,.log"
            onChange={handleFileUpload}
            style={{ display: 'none' }}
          />

          <select
            className="format-select"
            value={format}
            onChange={(e) => setFormat(e.target.value)}
            disabled={isLoading}
          >
            <option value="auto">Auto-detect format</option>
            <option value="json">JSON</option>
            <option value="plaintext">Plain Text</option>
          </select>
        </div>

        <button
          className="analyze-btn"
          onClick={handleSubmit}
          disabled={isLoading || !logText.trim()}
        >
          {isLoading ? 'Analyzing...' : 'Analyze'}
        </button>
      </div>
    </div>
  );
}
