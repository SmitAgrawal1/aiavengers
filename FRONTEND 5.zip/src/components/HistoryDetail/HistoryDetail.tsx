import { HistoryDetailResponse } from '../../types';
import AnalysisResult from '../AnalysisResult/AnalysisResult';
import './HistoryDetail.css';

interface HistoryDetailProps {
  detail: HistoryDetailResponse;
  onBack: () => void;
}

export default function HistoryDetail({ detail, onBack }: HistoryDetailProps) {
  return (
    <div className="history-detail">
      <button className="back-btn" onClick={onBack}>← Back to History</button>

      <div className="detail-header">
        <h3>Analysis Session</h3>
        <div className="detail-meta">
          <span>Date: {new Date(detail.created_at).toLocaleString()}</span>
          <span>Entries: {detail.entry_count}</span>
          <span>Format: {detail.input_format}</span>
          <span className={`status-badge status-${detail.status}`}>{detail.status}</span>
        </div>
      </div>

      <details className="original-log-section">
        <summary>Original Log Input</summary>
        <pre className="original-log-text">{detail.input_text}</pre>
      </details>

      {detail.anomalies.length === 0 ? (
        <p className="no-anomalies-detail">No anomalies were detected.</p>
      ) : (
        <div className="detail-anomalies">
          <h4>{detail.anomalies.length} anomal{detail.anomalies.length === 1 ? 'y' : 'ies'} detected</h4>
          {detail.anomalies.map((anomaly) => (
            <AnalysisResult
              key={anomaly.anomaly_id}
              anomaly={anomaly}
              sessionId={detail.session_id}
            />
          ))}
        </div>
      )}
    </div>
  );
}
