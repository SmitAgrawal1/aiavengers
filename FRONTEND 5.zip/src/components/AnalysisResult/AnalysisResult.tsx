import { AnomalyResponse } from '../../types';
import FeedbackButtons from '../FeedbackButtons/FeedbackButtons';
import './AnalysisResult.css';

interface AnalysisResultProps {
  anomaly: AnomalyResponse;
  sessionId: string;
  relatedTypes?: string[];
}

const severityColors: Record<string, string> = {
  low: '#38a169',
  medium: '#d69e2e',
  high: '#e53e3e',
  critical: '#9b2c2c',
};

export default function AnalysisResult({ anomaly, sessionId, relatedTypes }: AnalysisResultProps) {
  return (
    <div className="result-card">
      <div className="result-header">
        <span className="anomaly-type-badge">{anomaly.anomaly_type.replace(/_/g, ' ')}</span>
        <span
          className="severity-badge"
          style={{ background: severityColors[anomaly.severity] || '#666' }}
        >
          {anomaly.severity}
        </span>
        <span className="confidence-badge">
          {Math.round(anomaly.confidence_score * 100)}% confidence
        </span>
      </div>

      {relatedTypes && relatedTypes.length > 0 && (
        <div className="related-anomalies">
          <span className="related-label">Related anomalies:</span>
          {relatedTypes.map((t) => (
            <span key={t} className="related-badge">{t.replace(/_/g, ' ')}</span>
          ))}
        </div>
      )}

      {anomaly.explanation && (
        <div className="result-body">
          <div className="explanation-section">
            <h4>Summary</h4>
            <p>{anomaly.explanation.summary}</p>
          </div>

          <div className="explanation-section">
            <h4>Root Cause</h4>
            <p>{anomaly.explanation.root_cause}</p>
          </div>

          <div className="explanation-section">
            <h4>Remediation Steps</h4>
            <p className="remediation-text">{anomaly.explanation.remediation_steps}</p>
          </div>
        </div>
      )}

      {!anomaly.explanation && (
        <div className="result-body">
          <p className="no-explanation">
            Explanation generation failed. Showing raw detection results.
          </p>
        </div>
      )}

      <details className="matched-log-details">
        <summary>Matched Log Segment</summary>
        <pre className="matched-log-text">{anomaly.matched_log_text}</pre>
      </details>

      <FeedbackButtons
        sessionId={sessionId}
        anomalyId={anomaly.anomaly_id}
        existingFeedback={anomaly.feedback?.feedback_type}
      />
    </div>
  );
}
