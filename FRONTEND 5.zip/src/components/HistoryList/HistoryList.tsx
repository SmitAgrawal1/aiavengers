import { HistoryListItem } from '../../types';
import './HistoryList.css';

interface HistoryListProps {
  items: HistoryListItem[];
  onSelect: (sessionId: string) => void;
  page: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export default function HistoryList({ items, onSelect, page, totalPages, onPageChange }: HistoryListProps) {
  if (items.length === 0) {
    return <p className="no-history">No analysis history yet.</p>;
  }

  return (
    <div className="history-list">
      <table className="history-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Entries</th>
            <th>Format</th>
            <th>Status</th>
            <th>Anomalies</th>
            <th>Summary</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.session_id}>
              <td>{new Date(item.created_at).toLocaleString()}</td>
              <td>{item.entry_count}</td>
              <td>{item.input_format}</td>
              <td>
                <span className={`status-badge status-${item.status}`}>{item.status}</span>
              </td>
              <td>{item.anomaly_count}</td>
              <td className="summary-cell">{item.summary}</td>
              <td>
                <button className="view-btn" onClick={() => onSelect(item.session_id)}>
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {totalPages > 1 && (
        <div className="pagination">
          <button disabled={page <= 1} onClick={() => onPageChange(page - 1)}>Previous</button>
          <span>Page {page} of {totalPages}</span>
          <button disabled={page >= totalPages} onClick={() => onPageChange(page + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
