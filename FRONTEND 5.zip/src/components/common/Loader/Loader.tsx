import './Loader.css';

interface LoaderProps {
  message?: string;
}

export default function Loader({ message = 'Analyzing logs...' }: LoaderProps) {
  return (
    <div className="loader-container">
      <div className="spinner" />
      <p className="loader-message">{message}</p>
    </div>
  );
}
