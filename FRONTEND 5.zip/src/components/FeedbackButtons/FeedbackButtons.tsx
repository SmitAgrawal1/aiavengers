import { useState } from 'react';
import { submitFeedback } from '../../services/feedbackService';
import './FeedbackButtons.css';

interface FeedbackButtonsProps {
  sessionId: string;
  anomalyId: string;
  existingFeedback?: string | null;
}

export default function FeedbackButtons({ sessionId, anomalyId, existingFeedback }: FeedbackButtonsProps) {
  const [submitted, setSubmitted] = useState<string | null>(existingFeedback || null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleFeedback = async (type: 'thumbs_up' | 'thumbs_down') => {
    setLoading(true);
    try {
      const response = await submitFeedback({
        session_id: sessionId,
        anomaly_id: anomalyId,
        feedback_type: type,
      });
      setSubmitted(type);
      setMessage(response.message);
    } catch {
      setMessage('Failed to submit feedback.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="feedback-container">
        <span className={`feedback-submitted ${submitted}`}>
          {submitted === 'thumbs_up' ? '👍' : '👎'} {message || 'Feedback submitted'}
        </span>
      </div>
    );
  }

  return (
    <div className="feedback-container">
      <span className="feedback-label">Was this helpful?</span>
      <button
        className="feedback-btn thumbs-up"
        onClick={() => handleFeedback('thumbs_up')}
        disabled={loading}
        title="Helpful"
      >
        👍
      </button>
      <button
        className="feedback-btn thumbs-down"
        onClick={() => handleFeedback('thumbs_down')}
        disabled={loading}
        title="Not helpful"
      >
        👎
      </button>
    </div>
  );
}
