export interface ExplanationResponse {
  explanation_id: string;
  summary: string;
  root_cause: string;
  remediation_steps: string;
}

export interface FeedbackInfo {
  feedback_id: string;
  feedback_type: 'thumbs_up' | 'thumbs_down';
  created_at: string;
}

export interface AnomalyResponse {
  anomaly_id: string;
  anomaly_type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence_score: number;
  matched_log_text: string;
  explanation: ExplanationResponse | null;
  feedback: FeedbackInfo | null;
}

export interface AnalyzeRequest {
  log_text?: string;
  log_file_content?: string;
  input_format?: 'json' | 'plaintext';
}

export interface AnalyzeResponse {
  session_id: string;
  status: 'processing' | 'completed' | 'error';
  created_at: string;
  entry_count: number;
  input_format: string;
  anomalies: AnomalyResponse[];
  message: string;
}

export interface FeedbackRequest {
  session_id: string;
  anomaly_id: string;
  feedback_type: 'thumbs_up' | 'thumbs_down';
}

export interface FeedbackResponse {
  feedback_id: string;
  feedback_type: 'thumbs_up' | 'thumbs_down';
  ingested_to_chromadb: boolean;
  message: string;
}

export interface HistoryListItem {
  session_id: string;
  created_at: string;
  entry_count: number;
  input_format: string;
  status: string;
  anomaly_count: number;
  summary: string;
}

export interface HistoryListResponse {
  items: HistoryListItem[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface HistoryDetailResponse {
  session_id: string;
  created_at: string;
  input_text: string;
  input_format: string;
  entry_count: number;
  status: string;
  anomalies: AnomalyResponse[];
}

export interface HealthResponse {
  status: 'healthy' | 'unhealthy';
  chromadb: string;
  sqlite: string;
  knowledge_base_size: number;
  version: string;
  error?: string;
}
