import { Routes, Route } from 'react-router-dom';
import Navbar from './components/common/Navbar/Navbar';
import AnalyzePage from './pages/AnalyzePage/AnalyzePage';
import HistoryPage from './pages/HistoryPage/HistoryPage';
import './App.css';

export default function App() {
  return (
    <div className="app">
      <Navbar />
      <main className="app-main">
        <Routes>
          <Route path="/" element={<AnalyzePage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/history/:sessionId" element={<HistoryPage />} />
        </Routes>
      </main>
    </div>
  );
}
