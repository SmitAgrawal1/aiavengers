import apiClient from './apiClient';
import { FeedbackRequest, FeedbackResponse } from '../types';

export async function submitFeedback(request: FeedbackRequest): Promise<FeedbackResponse> {
  const response = await apiClient.post<FeedbackResponse>('/feedback', request);
  return response.data;
}
