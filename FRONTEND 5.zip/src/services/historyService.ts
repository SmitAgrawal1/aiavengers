import apiClient from './apiClient';
import { HistoryListResponse, HistoryDetailResponse } from '../types';

export async function getHistoryList(
  page = 1,
  pageSize = 20,
  sortBy = 'created_at',
  sortOrder = 'desc'
): Promise<HistoryListResponse> {
  const response = await apiClient.get<HistoryListResponse>('/history', {
    params: { page, page_size: pageSize, sort_by: sortBy, sort_order: sortOrder },
  });
  return response.data;
}

export async function getHistoryDetail(sessionId: string): Promise<HistoryDetailResponse> {
  const response = await apiClient.get<HistoryDetailResponse>(`/history/${sessionId}`);
  return response.data;
}
