import apiClient from './apiClient';
import { AnalyzeRequest, AnalyzeResponse } from '../types';

export async function analyzeLog(request: AnalyzeRequest): Promise<AnalyzeResponse> {
  const response = await apiClient.post<AnalyzeResponse>('/analyze', request);
  return response.data;
}
