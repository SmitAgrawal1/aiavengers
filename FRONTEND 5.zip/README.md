# Log Anomaly Assistant — Frontend

React + TypeScript frontend for the Performance Engineering Log Anomaly Explanation Assistant.

## Prerequisites

- Node.js 18+

## Setup

```bash
cd frontend
npm install
```

## Run

```bash
npm run dev
```

Opens at http://localhost:5173

## Pages

- **/** — Analyze: Paste or upload logs, view anomaly explanations with feedback buttons
- **/history** — History: Browse past analysis sessions
- **/history/:id** — Detail: View full analysis session detail

## Components

| Component | Description |
|-----------|-------------|
| `LogInput` | Text area + file upload for log input |
| `AnalysisResult` | Anomaly card with explanation, severity, confidence |
| `FeedbackButtons` | Thumbs up/down feedback for explanations |
| `HistoryList` | Paginated table of past analyses |
| `HistoryDetail` | Full detail view of a session |
| `Navbar` | Navigation bar |
| `Loader` | Loading spinner |
| `ErrorMessage` | Error display with retry |

## Project Structure

```
frontend/src/
├── components/        # Reusable UI components
│   ├── AnalysisResult/
│   ├── FeedbackButtons/
│   ├── HistoryDetail/
│   ├── HistoryList/
│   ├── LogInput/
│   └── common/
├── pages/             # Page-level components
│   ├── AnalyzePage/
│   └── HistoryPage/
├── services/          # API client and service functions
├── types/             # TypeScript interfaces
├── App.tsx            # Router setup
└── main.tsx           # Entry point
```
