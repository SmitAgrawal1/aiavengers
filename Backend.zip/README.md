# Log Anomaly Assistant — Backend

Python FastAPI backend for the Performance Engineering Log Anomaly Explanation Assistant.

## Prerequisites

- Python 3.11+
- OpenAI API key

## Setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
```

## Seed Knowledge Base

```bash
python scripts/seed_knowledge_base.py
```

This loads 800+ labeled log entries into ChromaDB.

## Run

```bash
uvicorn app.main:app --reload --port 8000
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/analyze` | Analyze log text for anomalies |
| POST | `/api/v1/ingest` | Ingest labeled entries into ChromaDB |
| POST | `/api/v1/feedback` | Submit thumbs up/down feedback |
| GET | `/api/v1/history` | List past analysis sessions |
| GET | `/api/v1/history/{id}` | Get analysis session detail |
| GET | `/api/v1/health` | Health check |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | — | Required. OpenAI API key |
| `OPENAI_MODEL` | `gpt-4o` | OpenAI model name |
| `CHROMADB_PATH` | `./data/chromadb` | ChromaDB persistence directory |
| `SQLITE_URL` | `sqlite:///./data/analysis.db` | SQLite database URL |
| `CORS_ORIGINS` | `http://localhost:5173` | Allowed CORS origins |
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | Sentence transformer model |
| `LLM_TEMPERATURE` | `0.3` | LLM temperature |
| `LLM_MAX_TOKENS` | `2000` | LLM max tokens |
| `MAX_LOG_ENTRIES` | `500` | Max log entries per request |
| `MAX_INPUT_SIZE_BYTES` | `2097152` | Max input size (2 MB) |

## Project Structure

```
backend/
├── app/
│   ├── api/           # FastAPI route handlers
│   ├── db/            # Database clients (SQLite, ChromaDB)
│   ├── models/        # ORM models and Pydantic schemas
│   ├── services/      # Business logic
│   └── main.py        # App entry point
├── data/              # ChromaDB data, seed logs, SQLite DB
├── scripts/           # Seed and utility scripts
└── requirements.txt
```
