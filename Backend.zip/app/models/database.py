import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Integer, Float, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


def generate_uuid() -> str:
    return str(uuid.uuid4())


class AnalysisSessionDB(Base):
    __tablename__ = "analysis_sessions"

    id = Column(String, primary_key=True, default=generate_uuid)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc), index=True)
    input_text = Column(Text, nullable=False)
    input_format = Column(String, nullable=False)
    entry_count = Column(Integer, nullable=False)
    status = Column(String, nullable=False, default="processing")
    error_message = Column(Text, nullable=True)

    anomalies = relationship("AnomalyDB", back_populates="session", cascade="all, delete-orphan")
    feedbacks = relationship("FeedbackDB", back_populates="session", cascade="all, delete-orphan")


class AnomalyDB(Base):
    __tablename__ = "anomalies"

    id = Column(String, primary_key=True, default=generate_uuid)
    session_id = Column(String, ForeignKey("analysis_sessions.id"), nullable=False)
    anomaly_type = Column(String, nullable=False)
    severity = Column(String, nullable=False)
    confidence_score = Column(Float, nullable=False)
    log_entries_start = Column(Integer, nullable=False)
    log_entries_end = Column(Integer, nullable=False)
    matched_log_text = Column(Text, nullable=False)

    session = relationship("AnalysisSessionDB", back_populates="anomalies")
    explanation = relationship("ExplanationDB", back_populates="anomaly", uselist=False, cascade="all, delete-orphan")
    feedback = relationship("FeedbackDB", back_populates="anomaly", uselist=False, cascade="all, delete-orphan")


class ExplanationDB(Base):
    __tablename__ = "explanations"

    id = Column(String, primary_key=True, default=generate_uuid)
    anomaly_id = Column(String, ForeignKey("anomalies.id"), nullable=False, unique=True)
    summary = Column(Text, nullable=False)
    root_cause = Column(Text, nullable=False)
    remediation_steps = Column(Text, nullable=False)
    raw_llm_response = Column(Text, nullable=True)

    anomaly = relationship("AnomalyDB", back_populates="explanation")


class FeedbackDB(Base):
    __tablename__ = "feedbacks"

    id = Column(String, primary_key=True, default=generate_uuid)
    session_id = Column(String, ForeignKey("analysis_sessions.id"), nullable=False)
    anomaly_id = Column(String, ForeignKey("anomalies.id"), nullable=False, unique=True)
    feedback_type = Column(String, nullable=False)
    created_at = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    ingested_to_chromadb = Column(Boolean, nullable=False, default=False)

    session = relationship("AnalysisSessionDB", back_populates="feedbacks")
    anomaly = relationship("AnomalyDB", back_populates="feedback")
