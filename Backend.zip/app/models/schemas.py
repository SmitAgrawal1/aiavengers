from datetime import datetime
from pydantic import BaseModel, Field


# --- Analysis ---

class AnalyzeRequest(BaseModel):
    log_text: str | None = None
    log_file_content: str | None = None
    input_format: str | None = None


class ExplanationOut(BaseModel):
    explanation_id: str
    summary: str
    root_cause: str
    remediation_steps: str


class FeedbackOut(BaseModel):
    feedback_id: str
    feedback_type: str
    created_at: datetime


class AnomalyOut(BaseModel):
    anomaly_id: str
    anomaly_type: str
    severity: str
    confidence_score: float
    matched_log_text: str
    explanation: ExplanationOut | None = None
    feedback: FeedbackOut | None = None


class AnalyzeResponse(BaseModel):
    session_id: str
    status: str
    created_at: datetime
    entry_count: int
    input_format: str
    anomalies: list[AnomalyOut]
    message: str


# --- Ingestion ---

class IngestEntry(BaseModel):
    timestamp: str | None = None
    severity: str = "ERROR"
    component: str | None = None
    message: str
    anomaly_type: str
    root_cause: str
    remediation_steps: str


class IngestRequest(BaseModel):
    entries: list[IngestEntry] = Field(min_length=1)


class IngestResponse(BaseModel):
    ingested_count: int
    skipped_count: int
    skipped_reasons: list[str]
    total_knowledge_base_size: int


# --- Feedback ---

class FeedbackRequest(BaseModel):
    session_id: str
    anomaly_id: str
    feedback_type: str = Field(pattern=r"^(thumbs_up|thumbs_down)$")


class FeedbackResponse(BaseModel):
    feedback_id: str
    feedback_type: str
    ingested_to_chromadb: bool
    message: str


# --- History ---

class HistoryListItem(BaseModel):
    session_id: str
    created_at: datetime
    entry_count: int
    input_format: str
    status: str
    anomaly_count: int
    summary: str


class HistoryListResponse(BaseModel):
    items: list[HistoryListItem]
    total: int
    page: int
    page_size: int
    total_pages: int


class HistoryDetailResponse(BaseModel):
    session_id: str
    created_at: datetime
    input_text: str
    input_format: str
    entry_count: int
    status: str
    anomalies: list[AnomalyOut]


# --- Health ---

class HealthResponse(BaseModel):
    status: str
    chromadb: str
    sqlite: str
    knowledge_base_size: int
    version: str
    error: str | None = None
