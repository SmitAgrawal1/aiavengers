from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.models.database import Base
from app.db.sqlite_client import engine

app = FastAPI(title="Log Anomaly Assistant API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)


# Import and include routers
from app.api.routes_analysis import router as analysis_router
from app.api.routes_ingestion import router as ingestion_router
from app.api.routes_feedback import router as feedback_router
from app.api.routes_history import router as history_router
from app.api.routes_health import router as health_router

app.include_router(analysis_router, prefix="/api/v1")
app.include_router(ingestion_router, prefix="/api/v1")
app.include_router(feedback_router, prefix="/api/v1")
app.include_router(history_router, prefix="/api/v1")
app.include_router(health_router, prefix="/api/v1")
