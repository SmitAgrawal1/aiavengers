import json
import re
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ParsedLogEntry:
    timestamp: str = ""
    severity: str = "INFO"
    component: str = ""
    message: str = ""
    raw: str = ""


@dataclass
class LogChunk:
    entries: list[ParsedLogEntry] = field(default_factory=list)
    text: str = ""
    start_index: int = 0
    end_index: int = 0


# Common plain text log patterns
_PLAIN_TEXT_PATTERNS = [
    # ISO timestamp + level + component + message
    re.compile(
        r"^(?P<timestamp>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[\.\d]*Z?)\s+"
        r"(?P<severity>DEBUG|INFO|WARN|WARNING|ERROR|FATAL|CRITICAL)\s+"
        r"(?P<component>\S+)\s+"
        r"(?P<message>.+)$"
    ),
    # Bracket format: [timestamp] [level] [component] message
    re.compile(
        r"^\[(?P<timestamp>[^\]]+)\]\s*\[(?P<severity>[^\]]+)\]\s*\[(?P<component>[^\]]+)\]\s*(?P<message>.+)$"
    ),
    # Simple: timestamp level message
    re.compile(
        r"^(?P<timestamp>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[\.\d]*Z?)\s+"
        r"(?P<severity>DEBUG|INFO|WARN|WARNING|ERROR|FATAL|CRITICAL)\s+"
        r"(?P<message>.+)$"
    ),
]

_NOISE_PATTERNS = [
    re.compile(r"health[\s_-]?check", re.IGNORECASE),
    re.compile(r"heartbeat", re.IGNORECASE),
    re.compile(r"ping\s*$", re.IGNORECASE),
    re.compile(r"^[\s]*$"),
]


def detect_format(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("[") or stripped.startswith("{"):
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, (list, dict)):
                return "json"
        except json.JSONDecodeError:
            pass
    return "plaintext"


def _parse_json_logs(text: str) -> list[ParsedLogEntry]:
    data = json.loads(text.strip())
    if isinstance(data, dict):
        data = [data]

    entries = []
    for item in data:
        if not isinstance(item, dict):
            continue
        entry = ParsedLogEntry(
            timestamp=str(item.get("timestamp", "")),
            severity=str(item.get("severity", item.get("level", "INFO"))).upper(),
            component=str(item.get("component", item.get("source", ""))),
            message=str(item.get("message", item.get("msg", ""))),
            raw=json.dumps(item),
        )
        entries.append(entry)
    return entries


def _parse_plain_text_logs(text: str) -> list[ParsedLogEntry]:
    entries = []
    for line in text.strip().split("\n"):
        line = line.strip()
        if not line:
            continue

        parsed = False
        for pattern in _PLAIN_TEXT_PATTERNS:
            match = pattern.match(line)
            if match:
                groups = match.groupdict()
                entry = ParsedLogEntry(
                    timestamp=groups.get("timestamp", ""),
                    severity=groups.get("severity", "INFO").upper(),
                    component=groups.get("component", ""),
                    message=groups.get("message", ""),
                    raw=line,
                )
                entries.append(entry)
                parsed = True
                break

        if not parsed:
            entries.append(ParsedLogEntry(message=line, raw=line))

    return entries


def _is_noise(entry: ParsedLogEntry) -> bool:
    for pattern in _NOISE_PATTERNS:
        if pattern.search(entry.message):
            return True
    return False


def _remove_duplicates(entries: list[ParsedLogEntry]) -> list[ParsedLogEntry]:
    seen: set[str] = set()
    unique = []
    for entry in entries:
        key = f"{entry.timestamp}|{entry.severity}|{entry.message}"
        if key not in seen:
            seen.add(key)
            unique.append(entry)
    return unique


def _chunk_entries(entries: list[ParsedLogEntry], max_chunk_size: int = 5) -> list[LogChunk]:
    if not entries:
        return []

    chunks: list[LogChunk] = []
    current_entries: list[ParsedLogEntry] = []
    chunk_start = 0

    for i, entry in enumerate(entries):
        current_entries.append(entry)

        if len(current_entries) >= max_chunk_size:
            chunk_text = "\n".join(e.raw or e.message for e in current_entries)
            chunks.append(LogChunk(
                entries=list(current_entries),
                text=chunk_text,
                start_index=chunk_start,
                end_index=i,
            ))
            current_entries = []
            chunk_start = i + 1

    if current_entries:
        chunk_text = "\n".join(e.raw or e.message for e in current_entries)
        chunks.append(LogChunk(
            entries=list(current_entries),
            text=chunk_text,
            start_index=chunk_start,
            end_index=len(entries) - 1,
        ))

    return chunks


def parse_logs(text: str, input_format: str | None = None) -> tuple[str, list[ParsedLogEntry], list[LogChunk]]:
    if input_format is None:
        input_format = detect_format(text)

    if input_format == "json":
        entries = _parse_json_logs(text)
    else:
        entries = _parse_plain_text_logs(text)

    # Filter noise
    entries = [e for e in entries if not _is_noise(e)]

    # Remove duplicates
    entries = _remove_duplicates(entries)

    # Chunk
    chunks = _chunk_entries(entries)

    return input_format, entries, chunks
