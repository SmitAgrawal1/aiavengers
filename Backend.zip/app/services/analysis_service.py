import logging
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.db.chromadb_client import get_chromadb_client
from app.models.database import AnalysisSessionDB, AnomalyDB, ExplanationDB
from app.services.log_parser import parse_logs, LogChunk
from app.services.explanation_service import generate_explanation

logger = logging.getLogger(__name__)


def _search_knowledge_base(chunk_text: str) -> list[dict]:
    try:
        client = get_chromadb_client()
        results = client.similarity_search(chunk_text, n_results=5)

        entries = []
        if results and results.get("documents"):
            docs = results["documents"][0] if results["documents"] else []
            metas = results["metadatas"][0] if results.get("metadatas") else []
            distances = results["distances"][0] if results.get("distances") else []

            for i, doc in enumerate(docs):
                meta = metas[i] if i < len(metas) else {}
                distance = distances[i] if i < len(distances) else 1.0
                entries.append({
                    "document": doc,
                    "metadata": meta,
                    "distance": distance,
                })
        return entries
    except Exception as e:
        logger.error(f"ChromaDB search failed: {e}")
        return []


def _calculate_confidence(distance: float) -> float:
    # ChromaDB returns L2 distance; lower = more similar
    # Convert to 0-1 confidence score
    confidence = max(0.0, min(1.0, 1.0 - (distance / 2.0)))
    return round(confidence, 2)


def analyze_log(db: Session, input_text: str, input_format: str | None = None) -> dict:
    # Create session record
    session = AnalysisSessionDB(
        input_text=input_text,
        input_format=input_format or "plaintext",
        entry_count=0,
        status="processing",
    )
    db.add(session)
    db.flush()

    try:
        # Parse and chunk the log
        detected_format, entries, chunks = parse_logs(input_text, input_format)
        session.input_format = detected_format
        session.entry_count = len(entries)

        if not chunks:
            session.status = "completed"
            db.commit()
            return _build_response(session, [])

        # First pass: identify anomaly types per chunk via ChromaDB search
        chunk_kb_results: list[tuple[LogChunk, list[dict], float]] = []
        detected_types: list[str] = []

        for chunk in chunks:
            kb_entries = _search_knowledge_base(chunk.text)
            if not kb_entries:
                continue
            top_entry = kb_entries[0]
            top_distance = top_entry.get("distance", 2.0)
            confidence = _calculate_confidence(top_distance)
            if confidence < 0.3:
                continue
            chunk_kb_results.append((chunk, kb_entries, confidence))
            anomaly_type = top_entry.get("metadata", {}).get("anomaly_type", "unknown")
            if anomaly_type not in detected_types:
                detected_types.append(anomaly_type)

        all_anomalies = []

        # Second pass: generate explanations with cross-anomaly context
        for chunk, kb_entries, confidence in chunk_kb_results:
            top_entry = kb_entries[0]

            # Pass other detected types for causal relationship inference
            other_types = [t for t in detected_types if t != top_entry.get("metadata", {}).get("anomaly_type")]
            llm_result = generate_explanation(
                chunk.text, kb_entries, other_types if other_types else None
            )

            if llm_result and llm_result.get("anomalies"):
                for anomaly_data in llm_result["anomalies"]:
                    anomaly = AnomalyDB(
                        session_id=session.id,
                        anomaly_type=anomaly_data.get("anomaly_type", "unknown"),
                        severity=anomaly_data.get("severity", "medium"),
                        confidence_score=confidence,
                        log_entries_start=chunk.start_index,
                        log_entries_end=chunk.end_index,
                        matched_log_text=chunk.text,
                    )
                    db.add(anomaly)
                    db.flush()

                    remediation_raw = anomaly_data.get("remediation_steps", "")
                    if isinstance(remediation_raw, list):
                        remediation_raw = "\n".join(remediation_raw)

                    explanation = ExplanationDB(
                        anomaly_id=anomaly.id,
                        summary=anomaly_data.get("summary", ""),
                        root_cause=anomaly_data.get("root_cause", ""),
                        remediation_steps=remediation_raw,
                        raw_llm_response=str(llm_result),
                    )
                    db.add(explanation)
                    all_anomalies.append((anomaly, explanation))
            else:
                # LLM failed — still record the anomaly match from RAG without explanation
                top_meta = top_entry.get("metadata", {})
                anomaly = AnomalyDB(
                    session_id=session.id,
                    anomaly_type=top_meta.get("anomaly_type", "unknown"),
                    severity=top_meta.get("severity", "medium"),
                    confidence_score=confidence,
                    log_entries_start=chunk.start_index,
                    log_entries_end=chunk.end_index,
                    matched_log_text=chunk.text,
                )
                db.add(anomaly)
                all_anomalies.append((anomaly, None))

        session.status = "completed"
        db.commit()
        return _build_response(session, all_anomalies)

    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        session.status = "error"
        session.error_message = str(e)
        db.commit()
        raise


def _build_response(session: AnalysisSessionDB, anomalies: list[tuple]) -> dict:
    anomaly_list = []
    for anomaly_db, explanation_db in anomalies:
        explanation_out = None
        if explanation_db:
            explanation_out = {
                "explanation_id": explanation_db.id,
                "summary": explanation_db.summary,
                "root_cause": explanation_db.root_cause,
                "remediation_steps": explanation_db.remediation_steps,
            }

        anomaly_list.append({
            "anomaly_id": anomaly_db.id,
            "anomaly_type": anomaly_db.anomaly_type,
            "severity": anomaly_db.severity,
            "confidence_score": anomaly_db.confidence_score,
            "matched_log_text": anomaly_db.matched_log_text,
            "explanation": explanation_out,
            "feedback": None,
        })

    count = len(anomaly_list)
    if count == 0:
        message = "No anomalies detected in the provided log segment."
    else:
        has_explanations = any(a["explanation"] is not None for a in anomaly_list)
        if has_explanations:
            message = f"Analysis complete. {count} anomal{'y' if count == 1 else 'ies'} detected."
        else:
            message = "Anomalies detected but explanation generation failed. Showing raw detection results."

    return {
        "session_id": session.id,
        "status": session.status,
        "created_at": session.created_at.isoformat(),
        "entry_count": session.entry_count,
        "input_format": session.input_format,
        "anomalies": anomaly_list,
        "message": message,
    }
