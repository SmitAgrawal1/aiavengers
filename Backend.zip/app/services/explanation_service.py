import json
import logging
from openai import OpenAI
from app.config import settings

logger = logging.getLogger(__name__)

_client: OpenAI | None = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        kwargs = {"api_key": settings.OPENAI_API_KEY}
        if settings.OPENAI_BASE_URL:
            kwargs["base_url"] = settings.OPENAI_BASE_URL
        _client = OpenAI(**kwargs)
    return _client


SYSTEM_PROMPT = """You are a performance engineering expert. Analyze the following log entries and the similar historical anomalies retrieved from the knowledge base. For each anomaly detected:

1. Identify the anomaly type (e.g., memory_leak, cpu_spike, network_timeout, disk_io_bottleneck, db_connection_pool_exhaustion, application_deadlock, service_dependency_failure, gc_pause, request_latency_degradation, auth_errors)
2. Determine the severity: low, medium, high, or critical
3. Explain what is happening in clear language
4. Provide the likely root cause
5. Suggest specific remediation steps

Respond in valid JSON format with this structure:
{
  "anomalies": [
    {
      "anomaly_type": "string",
      "severity": "low|medium|high|critical",
      "summary": "Brief description of the anomaly",
      "root_cause": "Detailed explanation of the likely root cause",
      "remediation_steps": "Numbered list of remediation steps",
      "related_anomalies": ["list of related anomaly types if any"]
    }
  ]
}

If no anomalies are detected, return: {"anomalies": []}
"""


def generate_explanation(
    log_chunk: str,
    retrieved_entries: list[dict],
    detected_anomaly_types: list[str] | None = None,
) -> dict | None:
    context_parts = []
    for entry in retrieved_entries:
        doc = entry.get("document", "")
        meta = entry.get("metadata", {})
        context_parts.append(
            f"Historical Anomaly:\n"
            f"  Type: {meta.get('anomaly_type', 'unknown')}\n"
            f"  Severity: {meta.get('severity', 'unknown')}\n"
            f"  Root Cause: {meta.get('root_cause', 'N/A')}\n"
            f"  Remediation: {meta.get('remediation_steps', 'N/A')}\n"
            f"  Log Pattern: {doc[:300]}\n"
        )

    context_text = "\n---\n".join(context_parts) if context_parts else "No historical data available."

    cross_anomaly_context = ""
    if detected_anomaly_types:
        cross_anomaly_context = (
            f"\n\nOther anomalies detected in the same log session: "
            f"{', '.join(detected_anomaly_types)}. "
            f"Consider causal relationships between these anomalies."
        )

    user_message = (
        f"Context from knowledge base:\n{context_text}\n\n"
        f"User log to analyze:\n{log_chunk}"
        f"{cross_anomaly_context}"
    )

    try:
        client = _get_client()
        response = client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_message},
            ],
            temperature=settings.LLM_TEMPERATURE,
            max_tokens=settings.LLM_MAX_TOKENS,
            response_format={"type": "json_object"},
        )

        content = response.choices[0].message.content
        if content:
            return json.loads(content)
        return None
    except Exception as e:
        logger.error(f"LLM explanation generation failed: {e}")
        return None
