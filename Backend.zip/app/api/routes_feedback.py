from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

from app.db.sqlite_client import get_db
from app.db.chromadb_client import get_chromadb_client
from app.models.database import AnalysisSessionDB, AnomalyDB, FeedbackDB
from app.models.schemas import FeedbackRequest, FeedbackResponse

router = APIRouter()


@router.post("/feedback", response_model=FeedbackResponse)
async def submit_feedback(request: FeedbackRequest, db: Session = Depends(get_db)):
    session = db.query(AnalysisSessionDB).filter(AnalysisSessionDB.id == request.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session or anomaly not found.")

    anomaly = (
        db.query(AnomalyDB)
        .filter(AnomalyDB.id == request.anomaly_id, AnomalyDB.session_id == request.session_id)
        .first()
    )
    if not anomaly:
        raise HTTPException(status_code=404, detail="Session or anomaly not found.")

    existing = db.query(FeedbackDB).filter(FeedbackDB.anomaly_id == request.anomaly_id).first()
    if existing:
        raise HTTPException(status_code=409, detail="Feedback already submitted for this anomaly.")

    ingested = False
    if request.feedback_type == "thumbs_up" and anomaly.explanation:
        try:
            chroma = get_chromadb_client()
            doc = anomaly.matched_log_text
            meta = {
                "anomaly_type": anomaly.anomaly_type,
                "severity": anomaly.severity,
                "root_cause": anomaly.explanation.root_cause,
                "remediation_steps": anomaly.explanation.remediation_steps,
                "source": "user_feedback",
                "component": "unknown",
                "timestamp": "",
            }
            chroma.add_entries(documents=[doc], metadatas=[meta])
            ingested = True
        except Exception:
            pass

    feedback = FeedbackDB(
        session_id=request.session_id,
        anomaly_id=request.anomaly_id,
        feedback_type=request.feedback_type,
        ingested_to_chromadb=ingested,
    )
    db.add(feedback)
    db.commit()

    if request.feedback_type == "thumbs_up":
        message = "Thank you! This explanation has been added to the knowledge base."
    else:
        message = "Thank you for your feedback."

    return FeedbackResponse(
        feedback_id=feedback.id,
        feedback_type=feedback.feedback_type,
        ingested_to_chromadb=ingested,
        message=message,
    )
