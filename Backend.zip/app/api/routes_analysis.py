import base64
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.config import settings
from app.db.sqlite_client import get_db
from app.models.schemas import AnalyzeRequest, AnalyzeResponse
from app.services.analysis_service import analyze_log
from app.services.log_parser import parse_logs

router = APIRouter()


@router.post("/analyze", response_model=AnalyzeResponse)
def analyze(request: AnalyzeRequest, db: Session = Depends(get_db)):
    # Determine input text
    input_text = None
    if request.log_text:
        input_text = request.log_text
    elif request.log_file_content:
        try:
            input_text = base64.b64decode(request.log_file_content).decode("utf-8")
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid base64-encoded file content.")

    if not input_text or not input_text.strip():
        raise HTTPException(status_code=400, detail="Log input must not be empty or whitespace-only.")

    # Check size limit (2 MB)
    if len(input_text.encode("utf-8")) > settings.MAX_INPUT_SIZE_BYTES:
        raise HTTPException(
            status_code=400,
            detail="Input exceeds maximum size limit (500 entries or 2 MB).",
        )

    # Pre-check entry count before full analysis
    try:
        _, entries, _ = parse_logs(input_text, request.input_format)
        if len(entries) > settings.MAX_LOG_ENTRIES:
            raise HTTPException(
                status_code=400,
                detail="Input exceeds maximum size limit (500 entries or 2 MB).",
            )
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(
            status_code=422,
            detail="Unable to parse log format. Supported formats: JSON array of log objects, plain text (one entry per line).",
        )

    try:
        result = analyze_log(db, input_text, request.input_format)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return result
