from fastapi import APIRouter
from fastapi.responses import JSONResponse
from sqlalchemy import text
from app.models.schemas import HealthResponse
from app.db.chromadb_client import get_chromadb_client
from app.db.sqlite_client import engine

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health_check():
    chromadb_status = "disconnected"
    kb_size = 0
    sqlite_status = "disconnected"
    error_msg = None

    try:
        client = get_chromadb_client()
        if client.is_connected():
            chromadb_status = "connected"
            kb_size = client.get_collection_count()
        else:
            error_msg = "ChromaDB connection failed"
    except Exception as e:
        error_msg = f"ChromaDB connection failed: {e}"

    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            sqlite_status = "connected"
    except Exception as e:
        error_msg = f"SQLite connection failed: {e}"

    overall = "healthy" if chromadb_status == "connected" and sqlite_status == "connected" else "unhealthy"

    response = HealthResponse(
        status=overall,
        chromadb=chromadb_status,
        sqlite=sqlite_status,
        knowledge_base_size=kb_size,
        version="0.1.0",
        error=error_msg,
    )

    if overall == "unhealthy":
        return JSONResponse(content=response.model_dump(), status_code=503)

    return response
