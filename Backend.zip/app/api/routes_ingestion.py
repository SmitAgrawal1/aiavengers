from fastapi import APIRouter, HTTPException
from app.models.schemas import IngestRequest, IngestResponse
from app.db.chromadb_client import get_chromadb_client

router = APIRouter()

VALID_SEVERITIES = {"DEBUG", "INFO", "WARN", "ERROR", "FATAL"}


@router.post("/ingest", response_model=IngestResponse)
async def ingest_entries(request: IngestRequest):
    chroma = get_chromadb_client()

    documents: list[str] = []
    metadatas: list[dict] = []
    skipped_reasons: list[str] = []

    for idx, entry in enumerate(request.entries):
        if not entry.message.strip():
            skipped_reasons.append(f"Empty message at index {idx}")
            continue

        if entry.severity and entry.severity.upper() not in VALID_SEVERITIES:
            skipped_reasons.append(
                f"Invalid severity '{entry.severity}' at index {idx}"
            )
            continue

        doc_text = (
            f"[{entry.severity}] [{entry.component or 'unknown'}] {entry.message}"
        )

        # Check for duplicate by exact document match
        try:
            existing = chroma.similarity_search(doc_text, n_results=1)
            if (
                existing
                and existing.get("documents")
                and existing["documents"][0]
                and existing["documents"][0][0] == doc_text
            ):
                skipped_reasons.append(f"Duplicate at index {idx}")
                continue
        except Exception:
            pass

        documents.append(doc_text)
        metadatas.append(
            {
                "anomaly_type": entry.anomaly_type,
                "severity": entry.severity.upper() if entry.severity else "ERROR",
                "component": entry.component or "unknown",
                "root_cause": entry.root_cause,
                "remediation_steps": entry.remediation_steps,
                "timestamp": entry.timestamp or "",
            }
        )

    ingested = chroma.add_entries(documents=documents, metadatas=metadatas)

    return IngestResponse(
        ingested_count=ingested,
        skipped_count=len(skipped_reasons),
        skipped_reasons=skipped_reasons,
        total_knowledge_base_size=chroma.get_collection_count(),
    )
