from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func

from app.db.sqlite_client import get_db
from app.models.database import AnalysisSessionDB, AnomalyDB
from app.models.schemas import HistoryListResponse, HistoryListItem, HistoryDetailResponse, AnomalyOut, ExplanationOut, FeedbackOut

router = APIRouter()

ALLOWED_SORT_FIELDS = {"created_at", "entry_count", "status"}


@router.get("/history", response_model=HistoryListResponse)
async def list_history(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    sort_by: str = Query("created_at"),
    sort_order: str = Query("desc", pattern=r"^(asc|desc)$"),
    db: Session = Depends(get_db),
):
    if sort_by not in ALLOWED_SORT_FIELDS:
        sort_by = "created_at"

    total = db.query(func.count(AnalysisSessionDB.id)).scalar() or 0
    total_pages = max(1, (total + page_size - 1) // page_size)

    col = getattr(AnalysisSessionDB, sort_by)
    order = col.desc() if sort_order == "desc" else col.asc()

    sessions = (
        db.query(AnalysisSessionDB)
        .order_by(order)
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    items = []
    for s in sessions:
        anomaly_count = db.query(func.count(AnomalyDB.id)).filter(AnomalyDB.session_id == s.id).scalar() or 0
        types = (
            db.query(AnomalyDB.anomaly_type)
            .filter(AnomalyDB.session_id == s.id)
            .distinct()
            .all()
        )
        summary = f"Detected: {', '.join(t[0] for t in types)}" if types else "No anomalies detected"
        items.append(HistoryListItem(
            session_id=s.id,
            created_at=s.created_at,
            entry_count=s.entry_count,
            input_format=s.input_format,
            status=s.status,
            anomaly_count=anomaly_count,
            summary=summary,
        ))

    return HistoryListResponse(
        items=items, total=total, page=page, page_size=page_size, total_pages=total_pages
    )


@router.get("/history/{session_id}", response_model=HistoryDetailResponse)
async def get_history_detail(session_id: str, db: Session = Depends(get_db)):
    session = (
        db.query(AnalysisSessionDB)
        .options(
            joinedload(AnalysisSessionDB.anomalies).joinedload(AnomalyDB.explanation),
            joinedload(AnalysisSessionDB.anomalies).joinedload(AnomalyDB.feedback),
        )
        .filter(AnalysisSessionDB.id == session_id)
        .first()
    )
    if not session:
        raise HTTPException(status_code=404, detail="Analysis session not found.")

    anomalies_out = []
    for a in session.anomalies:
        explanation_out = None
        if a.explanation:
            explanation_out = ExplanationOut(
                explanation_id=a.explanation.id,
                summary=a.explanation.summary,
                root_cause=a.explanation.root_cause,
                remediation_steps=a.explanation.remediation_steps,
            )
        feedback_out = None
        if a.feedback:
            feedback_out = FeedbackOut(
                feedback_id=a.feedback.id,
                feedback_type=a.feedback.feedback_type,
                created_at=a.feedback.created_at,
            )
        anomalies_out.append(AnomalyOut(
            anomaly_id=a.id,
            anomaly_type=a.anomaly_type,
            severity=a.severity,
            confidence_score=a.confidence_score,
            matched_log_text=a.matched_log_text,
            explanation=explanation_out,
            feedback=feedback_out,
        ))

    return HistoryDetailResponse(
        session_id=session.id,
        created_at=session.created_at,
        input_text=session.input_text,
        input_format=session.input_format,
        entry_count=session.entry_count,
        status=session.status,
        anomalies=anomalies_out,
    )
