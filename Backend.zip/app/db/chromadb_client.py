import uuid
import chromadb
from chromadb.utils import embedding_functions
from app.config import settings


class ChromaDBClient:
    def __init__(self):
        self._client = chromadb.PersistentClient(path=settings.CHROMADB_PATH)
        self._embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name=settings.EMBEDDING_MODEL
        )
        self._collection = self._client.get_or_create_collection(
            name=settings.CHROMA_COLLECTION_NAME,
            embedding_function=self._embedding_fn,
        )

    def add_entries(
        self,
        documents: list[str],
        metadatas: list[dict],
        ids: list[str] | None = None,
    ) -> int:
        if not documents:
            return 0
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in documents]
        self._collection.add(documents=documents, metadatas=metadatas, ids=ids)
        return len(documents)

    def similarity_search(self, query_text: str, n_results: int = 5) -> dict:
        results = self._collection.query(query_texts=[query_text], n_results=n_results)
        return results

    def get_collection_count(self) -> int:
        return self._collection.count()

    def is_connected(self) -> bool:
        try:
            self._client.heartbeat()
            return True
        except Exception:
            return False


_chromadb_client: ChromaDBClient | None = None


def get_chromadb_client() -> ChromaDBClient:
    global _chromadb_client
    if _chromadb_client is None:
        _chromadb_client = ChromaDBClient()
    return _chromadb_client
