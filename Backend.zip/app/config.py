import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o")
    OPENAI_BASE_URL: str = os.getenv("OPENAI_BASE_URL", "")
    CHROMADB_PATH: str = os.getenv("CHROMADB_PATH", "./data/chromadb")
    SQLITE_URL: str = os.getenv("SQLITE_URL", "sqlite:///./data/analysis_history.db")
    CORS_ORIGINS: list[str] = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.3"))
    LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "2000"))
    CHROMA_COLLECTION_NAME: str = "log_knowledge_base"
    MAX_LOG_ENTRIES: int = 500
    MAX_INPUT_SIZE_BYTES: int = 2 * 1024 * 1024  # 2 MB


settings = Settings()
