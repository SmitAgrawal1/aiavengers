import json
import random
from datetime import datetime, timedelta


def generate_seed_logs(output_file="data/seed_logs.json"):
    COMPONENTS = [
        "app-server-01", "app-server-02", "app-server-03",
        "worker-process-01", "worker-process-02", "worker-process-03",
        "db-primary", "db-replica-01", "db-replica-02",
        "cache-node-01", "cache-node-02",
        "api-gateway", "api-gateway-02",
        "storage-node-01", "storage-node-02",
        "service-worker-01", "service-worker-02", "service-worker-03",
        "payment-service", "auth-service", "notification-service",
        "jvm-instance-01", "jvm-instance-02", "jvm-instance-03",
        "nginx-lb-01", "redis-master", "elasticsearch-node-01",
    ]

    TEMPLATES = {
        "memory_leak": {
            "severities": ["FATAL", "ERROR", "WARN"],
            "messages": [
                "OutOfMemoryError: Java heap space. Memory usage reached {usage}% ({alloc}GB/4GB). GC overhead limit exceeded.",
                "Heap memory exhaustion detected. Heap size: {alloc}GB/4GB. Old generation: {old}%.",
                "Memory pressure alert: {usage}% heap utilization. Object allocation rate: {rate}MB/s.",
                "JVM heap growing unbounded. Current: {alloc}GB. Trend: +{rate}MB/min over last hour.",
                "OOME imminent. Survivor space full. Tenured generation at {old}%. Allocation failure count: {count}.",
            ],
            "root_causes": [
                "User session cache not evicting expired sessions. Circular reference in cache invalidation prevents GC of old session objects.",
                "Thread-local storage retaining request context objects across requests. Request pool not clearing thread-local variables on reuse.",
                "Event listener registry has duplicate listeners causing exponential memory consumption. Listeners not unregistered on service shutdown.",
                "Large object buffers for serialization retained in static cache without size bounds. Memory growth linear with connection count.",
                "Connection pool wrapper holding strong references to closed connections. Pool size growing without bound as connections cycle.",
            ],
            "remediation_steps": [
                "1. Enable verbose GC logging\n2. Review session eviction logic and cache TTL\n3. Implement manual session cleanup\n4. Set heap dump triggers\n5. Consider memory pooling",
                "1. Check thread-local variable lifecycle\n2. Add cleanup in finally blocks\n3. Increase heap size temporarily\n4. Monitor heap trend over 24h\n5. Review recent code changes",
                "1. Profile heap with jmap/jhat\n2. Identify top object allocators\n3. Fix unbounded caches\n4. Add WeakReference where appropriate\n5. Deploy and monitor",
            ],
        },
        "cpu_spike": {
            "severities": ["ERROR", "WARN"],
            "messages": [
                "CPU usage spike: {usage}% sustained for {dur}s. Thread pool exhausted. Queue depth: {queue}.",
                "High CPU alert: {cores} cores at {usage}%. Context switches: {switches}/sec. Load average: {load:.1f}.",
                "CPU contention detected. Runaway process consuming {usage}% CPU. System calls: {syscalls}/sec.",
                "Thread starvation: {blocked} threads in RUNNABLE state competing for CPU. Scheduler latency: {lat}ms.",
                "Compute spike detected. User CPU: {usage}%, System CPU: {sys}%. IRQ rate elevated.",
            ],
            "root_causes": [
                "Batch job started without thread pool throttling, causing {tasks} runaway tasks. Scheduler failed to check resources before launch.",
                "Infinite loop in request handler from recent deployment. Loop condition evaluates incorrectly on concurrent requests.",
                "Lock contention in connection pool causing spin-wait instead of yield. {blocked} threads blocked on lock.",
                "Regex backtracking on malformed input. Catastrophic backtracking in URL validation pattern consuming CPU.",
                "Unoptimized serialization method triggered by large payload. JSON serialization using reflection instead of generated code.",
            ],
            "remediation_steps": [
                "1. Kill runaway process\n2. Increase thread pool size\n3. Add resource checks before job submission\n4. Set CPU threshold alerts\n5. Review scheduling logic",
                "1. Rollback recent deployment\n2. Profile with async-profiler\n3. Fix loop/regex/serialization issue\n4. Deploy with gradual rollout\n5. Monitor CPU for 1 hour",
                "1. Identify hot threads with jstack\n2. Reduce lock scope or use lock-free structures\n3. Add backpressure to queue\n4. Test under load\n5. Deploy fix",
            ],
        },
        "disk_io_bottleneck": {
            "severities": ["ERROR", "WARN"],
            "messages": [
                "Disk I/O latency critical: read {rlat}ms, write {wlat}ms. IOPS at {iops_pct}%.",
                "Storage queue depth maximum. Read queue: {rq}, Write queue: {wq}. Service time: {svc}ms.",
                "Disk utilization: {util}%. Pending I/O: {pending}. Average wait: {wait}ms.",
                "I/O scheduler saturation. Throughput: {tp}MB/s (max {max_tp}MB/s). Latency spike detected.",
                "RAID controller write-back cache full. Forced write-through mode. Performance degraded {deg}x.",
            ],
            "root_causes": [
                "Backup process running during peak traffic consuming 70% of I/O bandwidth. Storage controller near thermal limits.",
                "Full table scan in batch job performing {scans} sequential disk reads without index optimization.",
                "WAL file and data files on same physical disk. Contention between data and log I/O causing head thrashing.",
                "Temporary file accumulation from failed jobs filling /tmp partition. Disk nearly full causing write amplification.",
                "SSD wear-leveling triggered during heavy write workload. Controller performing background compaction.",
            ],
            "remediation_steps": [
                "1. Reschedule backup to off-peak hours\n2. Check storage controller temp\n3. Enable I/O priority for critical workloads\n4. Add SSD cache tier\n5. Monitor IOPS trends",
                "1. Add database indexes\n2. Implement query pagination\n3. Run batch during maintenance window\n4. Monitor query execution time\n5. Profile I/O patterns",
                "1. Separate WAL to dedicated disk\n2. Clean up temporary files\n3. Monitor disk space usage\n4. Set up disk space alerts\n5. Review I/O scheduling policy",
            ],
        },
        "network_timeout": {
            "severities": ["ERROR", "WARN"],
            "messages": [
                "Connection timeout: {failed} failed requests in {dur}min. Socket timeout after {to}s. DNS: {dns:.1f}s.",
                "Network issues detected. Packet loss: {loss:.1f}%. Latency: {lat}ms. Jitter: {jitter}ms.",
                "Upstream unreachable. {timeouts} timeouts in {mins}min. Retries exhausted: {retries}.",
                "TCP connection reset by peer. {resets} RST packets received in {dur}s. Half-open connections: {half}.",
                "SSL/TLS handshake timeout. {handshake_fails} failed handshakes. Certificate chain validation: {cert_time}ms.",
            ],
            "root_causes": [
                "Upstream health check endpoint unresponsive due to application hang. DNS server experiencing high query latency.",
                "Firewall rule change blocked traffic to upstream service. Change not tested post-maintenance.",
                "DNS TTL expired and service endpoint IP changed. Client using stale DNS cache.",
                "Network interface duplex mismatch causing packet loss. Switch port auto-negotiation disabled.",
                "MTU mismatch between network segments causing packet fragmentation and retransmission.",
            ],
            "remediation_steps": [
                "1. Verify upstream health checks\n2. Restart DNS resolver\n3. Check network interface stats\n4. Increase timeout temporarily\n5. Trace network path",
                "1. Review recent firewall changes\n2. Verify network path\n3. Test with traceroute/ping\n4. Rollback firewall if needed\n5. Add network monitoring",
                "1. Flush DNS cache\n2. Verify DNS configuration\n3. Check NIC duplex settings\n4. Verify MTU across path\n5. Monitor packet loss rate",
            ],
        },
        "db_connection_pool_exhaustion": {
            "severities": ["FATAL", "ERROR"],
            "messages": [
                "Connection pool exhausted. Active: {active}/120. Queued: {queued}. Backlog growing at {rate} req/s.",
                "Pool saturation critical. {stale} stale connections. Wait timeout: {wait}s.",
                "DB access contention. {blocked} threads blocked on connection. Pool utilization: {util}%.",
                "Connection acquisition timeout after {wait}ms. Pool size: {active}. Idle: 0. Pending: {queued}.",
                "Database driver reported max connections reached. Overflow: {overflow}. Leaked connections suspected: {leaked}.",
            ],
            "root_causes": [
                "Long-running reporting query locked connection for {dur}min. Combined with traffic spike, all pool connections consumed.",
                "Connection leak in error handling path. Connections not returned to pool when exceptions occur in transaction block.",
                "Slow queries ({slow} queries over 30s) holding connections. Long-running transactions from batch processing.",
                "Pool configuration mismatch: app expects 200 connections but database max_connections set to 100.",
                "Orphaned connections from crashed worker threads. No connection validation on borrow from pool.",
            ],
            "remediation_steps": [
                "1. Kill long-running query\n2. Increase pool size\n3. Set query timeout\n4. Separate reporting and operational pools\n5. Alert on pool utilization > 80%",
                "1. Patch connection leak in error path\n2. Add try-finally for connection release\n3. Redeploy fix\n4. Monitor connection count\n5. Add static analysis for leaks",
                "1. Enable connection validation on borrow\n2. Set connection max lifetime\n3. Add idle connection eviction\n4. Review pool sizing\n5. Test under load",
            ],
        },
        "application_deadlock": {
            "severities": ["FATAL", "ERROR"],
            "messages": [
                "Deadlock detected. {threads} threads waiting. Thread pool unresponsive. Cycle: {cycle}.",
                "Critical thread contention. {blocked} threads blocked on mutex. Lock wait: {wait}s.",
                "Potential deadlock. Thread states: BLOCKED({b}), WAITING({w}), RUNNABLE({r}). Lock violation suspected.",
                "Thread dump shows circular dependency. {threads} threads in BLOCKED state for {wait}s.",
                "Deadlock in resource manager. Lock graph cycle detected. Affected operations: {ops}.",
            ],
            "root_causes": [
                "Two operations acquired locks in opposite order (Lock A→B vs B→A), causing circular wait. Detector timeout too high.",
                "Resource ordering protocol not followed. Handler acquires locks in non-deterministic order based on hashmap iteration.",
                "Lock upgrade scenario: read lock held while waiting for write lock, preventing other readers from releasing.",
                "Nested synchronized blocks across service boundaries. Cross-service lock dependency not documented.",
                "Database row-level locks held while waiting for application-level locks, creating cross-layer deadlock.",
            ],
            "remediation_steps": [
                "1. Restart affected service\n2. Review lock acquisition order\n3. Implement lock timeout with retry\n4. Enable deadlock detector logging\n5. Use static analysis for lock issues",
                "1. Identify held locks\n2. Establish consistent lock ordering\n3. Apply ordering to all paths\n4. Add lock acquisition logging\n5. Stress test for race conditions",
                "1. Capture thread dump\n2. Analyze lock dependency graph\n3. Refactor to avoid nested locks\n4. Use tryLock with timeout\n5. Deploy and monitor",
            ],
        },
        "service_dependency_failure": {
            "severities": ["ERROR"],
            "messages": [
                "Upstream service failing. {failed} failed requests. Error rate: {err_rate}%. Status: 503.",
                "Service dependency unavailable. Circuit breaker open. Retry storm: {retries} retries in {dur}s.",
                "Cascading failure detected. Dependency chain failing. Timeout propagating through system.",
                "Service mesh reports {failed} failed health probes for upstream dependency in last {dur}min.",
                "Fallback handler invoked {fallback} times. Primary service: DOWN. Degraded mode active.",
            ],
            "root_causes": [
                "Auth service deployment caused pod restart cascade. Load balancer routed traffic to restarting pods.",
                "Dependency service out of memory. Pod evicted due to resource limits. No auto-restart configured.",
                "DNS resolution returning stale IP for dependency. Service moved to new endpoint but DNS not updated.",
                "Downstream service database migration running during deployment. Service returning 503 during migration.",
                "Rate limiting by third-party API triggered. API quota exhausted. No backoff strategy in client.",
            ],
            "remediation_steps": [
                "1. Check dependency service status\n2. Verify load balancer health checks\n3. Add readiness probe delay\n4. Implement exponential backoff\n5. Enable circuit breaker",
                "1. Check memory in dependency service\n2. Increase memory allocation\n3. Enable auto-restart\n4. Monitor resource utilization\n5. Add pod autoscaling",
                "1. Verify DNS records\n2. Flush DNS cache\n3. Check service endpoint\n4. Implement graceful degradation\n5. Add dependency health dashboard",
            ],
        },
        "gc_pause": {
            "severities": ["WARN", "ERROR"],
            "messages": [
                "Long GC pause: {pause:.1f}s stop-the-world. Heap fragmentation: {frag}%.",
                "Full GC triggered. Pause: {pause_ms}ms. Young gen promotion: {promo}%. Survivor: {surv}%.",
                "GC pressure increasing. Frequency: {freq}/min. Avg pause: {avg}ms. Trend: increasing.",
                "G1 mixed collection taking {pause_ms}ms. Humongous allocation detected: {humongous}MB.",
                "CMS concurrent mode failure. Falling back to serial full GC. Pause: {pause:.1f}s.",
            ],
            "root_causes": [
                "Full GC triggered by heap fragmentation from large object allocation. Young gen promotion rate increased.",
                "Survivor space too small. Objects promoted prematurely to old gen causing GC cascades.",
                "Memory leak in off-heap storage causing JVM to compensate with more frequent GC.",
                "Humongous object allocation bypassing young generation. Objects larger than half a G1 region.",
                "CMS unable to keep up with old generation growth rate. Concurrent collection outpaced by allocation.",
            ],
            "remediation_steps": [
                "1. Analyze heap dump for large objects\n2. Tune GC parameters (NewRatio)\n3. Enable G1GC for better pause management\n4. Monitor survivor space\n5. Consider object pooling",
                "1. Review survivor space sizing\n2. Increase survivor ratio\n3. Adjust young gen size\n4. Monitor promotion rate\n5. Stress test new config",
                "1. Profile allocations with Flight Recorder\n2. Identify humongous allocations\n3. Reduce object sizes or pool them\n4. Increase G1 region size\n5. Monitor GC logs",
            ],
        },
        "request_latency_degradation": {
            "severities": ["WARN", "ERROR"],
            "messages": [
                "Latency degradation. P99: {p99}ms (baseline: 200ms). Spike: {spike}x. Affected: {affected} requests.",
                "Cascading latency. Response time increasing. Queue depth: {queue}. Processing stalled: {stalled}%.",
                "Slow query affecting latency. Query time: {qt}ms. Frequency: {freq}/s. Impact: {impact}% requests.",
                "SLA breach: P95 latency {p95}ms exceeds 500ms target. Median latency: {median}ms.",
                "Request timeout rate increased {spike}x. Downstream service adding {added}ms to response path.",
            ],
            "root_causes": [
                "Database query degraded due to missing index on high-traffic table. Plan changed to full table scan after data growth.",
                "Upstream microservice slow due to downstream dependency. Cascading delay through call chain.",
                "Cache miss ratio increased from 5% to 45% due to eviction. System fell back to expensive DB queries.",
                "Thread pool exhaustion causing request queuing. Pool sized for normal load, not current peak.",
                "Serialization overhead increased after schema change. New fields added without updating optimized serializers.",
            ],
            "remediation_steps": [
                "1. Identify slow queries with profiler\n2. Analyze query execution plans\n3. Add missing indexes\n4. Monitor post-fix performance\n5. Set up regression tests",
                "1. Trace request flow through services\n2. Identify slowest dependency\n3. Optimize or cache results\n4. Add distributed tracing\n5. Set latency budgets per service",
                "1. Review cache eviction policy\n2. Pre-warm cache after deployments\n3. Increase cache TTL\n4. Add cache hit rate monitoring\n5. Consider multi-tier caching",
            ],
        },
        "auth_errors": {
            "severities": ["ERROR", "WARN"],
            "messages": [
                "Auth failures: {failures} failed attempts. Error rate: {err_rate}%. Status: 401/403.",
                "Token expiry storm: {expired} expired tokens in {dur}min. Re-auth rate: {rate}x normal.",
                "Rate limiting engaged. {limited} requests limited. Limit: 100 req/min. Affected users: {affected}.",
                "OAuth token refresh failing. {failures} refresh failures. Token service: {status}.",
                "LDAP bind timeout. {failures} failed binds. Directory server response: {resp_time}ms.",
            ],
            "root_causes": [
                "Auth service token generation delays. Token latency: {lat}ms. Rate limiter triggered upstream.",
                "SSL certificate expiration in auth middleware. Certificate expired, not rotated.",
                "Rate limiting too aggressive after attack mitigation. Legitimate traffic hitting thresholds.",
                "Token signing key rotated but not propagated to all service instances. Split-brain token validation.",
                "LDAP directory server under maintenance. Connection pool to directory exhausted.",
            ],
            "remediation_steps": [
                "1. Check auth service latency\n2. Review rate limits\n3. Scale auth service\n4. Monitor auth metrics\n5. Implement token caching",
                "1. Verify SSL certificate dates\n2. Renew certificates\n3. Set up auto-renewal\n4. Add expiration alerts\n5. Check certificate chain",
                "1. Review post-incident rate limits\n2. Identify legitimate traffic patterns\n3. Adjust thresholds\n4. Whitelist known clients\n5. Monitor error rate",
            ],
        },
    }

    start_date = datetime(2026, 1, 1)
    end_date = datetime(2026, 3, 31)
    date_range = (end_date - start_date).days

    random.seed(42)
    logs = []

    for anomaly_type, template in TEMPLATES.items():
        for i in range(80):
            ts = start_date + timedelta(
                days=random.randint(0, date_range),
                seconds=random.randint(0, 86399),
            )
            component = random.choice(COMPONENTS)
            severity = random.choice(template["severities"])

            v = {
                "usage": random.randint(85, 99),
                "alloc": random.choice([3, 3.5, 3.8, 3.9]),
                "old": random.randint(60, 95),
                "rate": random.randint(5, 50),
                "count": random.randint(10, 500),
                "dur": random.randint(10, 120),
                "queue": random.randint(50, 2000),
                "cores": random.choice([4, 8, 16]),
                "switches": random.randint(5000, 50000),
                "load": random.uniform(2.0, 8.0),
                "sys": random.randint(10, 40),
                "syscalls": random.randint(1000, 20000),
                "lat": random.randint(50, 500),
                "blocked": random.randint(5, 80),
                "tasks": random.randint(50, 300),
                "rlat": random.randint(200, 2000),
                "wlat": random.randint(200, 2000),
                "iops_pct": random.randint(85, 99),
                "rq": random.randint(30, 200),
                "wq": random.randint(30, 200),
                "svc": random.randint(10, 150),
                "util": random.randint(85, 99),
                "pending": random.randint(50, 500),
                "wait": random.randint(10, 600),
                "scans": random.randint(500, 10000),
                "tp": random.randint(50, 200),
                "max_tp": 250,
                "deg": random.randint(2, 10),
                "failed": random.randint(20, 500),
                "to": random.randint(15, 60),
                "dns": random.uniform(1.0, 8.0),
                "mins": random.randint(2, 30),
                "loss": random.uniform(0.5, 8.0),
                "jitter": random.randint(5, 150),
                "timeouts": random.randint(10, 300),
                "retries": random.randint(20, 500),
                "active": random.randint(100, 120),
                "queued": random.randint(30, 800),
                "stale": random.randint(2, 30),
                "slow": random.randint(3, 50),
                "overflow": random.randint(5, 50),
                "leaked": random.randint(1, 10),
                "threads": random.randint(4, 30),
                "cycle": f"T{random.randint(1,20)}->LockA->T{random.randint(21,40)}->LockB",
                "b": random.randint(3, 20),
                "w": random.randint(2, 15),
                "r": random.randint(5, 30),
                "ops": random.choice(["read/write", "insert/update", "lock/unlock"]),
                "pause": random.uniform(1.0, 10.0),
                "pause_ms": random.randint(200, 8000),
                "frag": random.randint(30, 80),
                "promo": random.randint(10, 40),
                "surv": random.randint(20, 80),
                "freq": random.randint(5, 60),
                "avg": random.randint(100, 800),
                "humongous": random.randint(32, 256),
                "p99": random.randint(500, 8000),
                "p95": random.randint(400, 5000),
                "median": random.randint(100, 500),
                "spike": random.randint(2, 20),
                "affected": random.randint(20, 1000),
                "stalled": random.randint(10, 80),
                "qt": random.randint(200, 10000),
                "impact": random.randint(10, 80),
                "added": random.randint(50, 500),
                "failures": random.randint(10, 500),
                "err_rate": random.randint(3, 60),
                "expired": random.randint(20, 500),
                "limited": random.randint(50, 1000),
                "status": random.choice(["DEGRADED", "DOWN", "TIMEOUT"]),
                "resp_time": random.randint(500, 5000),
                "fallback": random.randint(10, 200),
                "half": random.randint(5, 50),
                "resets": random.randint(10, 100),
                "handshake_fails": random.randint(5, 50),
                "cert_time": random.randint(200, 2000),
            }

            try:
                msg = random.choice(template["messages"]).format(**v)
            except (KeyError, IndexError):
                msg = random.choice(template["messages"])

            try:
                rc = random.choice(template["root_causes"]).format(**v)
            except (KeyError, IndexError):
                rc = random.choice(template["root_causes"])

            rem = random.choice(template["remediation_steps"])

            logs.append({
                "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S") + "Z",
                "severity": severity,
                "component": component,
                "message": msg,
                "anomaly_type": anomaly_type,
                "root_cause": rc,
                "remediation_steps": rem,
            })

    random.shuffle(logs)

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=2)

    print(f"Generated {len(logs)} log entries to {output_file}")


if __name__ == "__main__":
    generate_seed_logs()
