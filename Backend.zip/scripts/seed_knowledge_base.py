"""Seed the ChromaDB knowledge base from seed_logs.json."""
import json
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.db.chromadb_client import get_chromadb_client


def seed_knowledge_base(data_path: str = "data/seed_logs.json"):
    with open(data_path, "r", encoding="utf-8") as f:
        entries = json.load(f)

    chroma = get_chromadb_client()
    existing_count = chroma.get_collection_count()
    print(f"Current knowledge base size: {existing_count}")

    documents = []
    metadatas = []

    for entry in entries:
        doc_text = (
            f"[{entry.get('severity', 'ERROR')}] "
            f"[{entry.get('component', 'unknown')}] "
            f"{entry['message']}"
        )
        documents.append(doc_text)
        metadatas.append({
            "anomaly_type": entry["anomaly_type"],
            "severity": entry.get("severity", "ERROR"),
            "component": entry.get("component", "unknown"),
            "root_cause": entry["root_cause"],
            "remediation_steps": entry["remediation_steps"],
            "timestamp": entry.get("timestamp", ""),
        })

    # Ingest in batches of 100
    batch_size = 100
    total_ingested = 0
    for i in range(0, len(documents), batch_size):
        batch_docs = documents[i : i + batch_size]
        batch_meta = metadatas[i : i + batch_size]
        count = chroma.add_entries(documents=batch_docs, metadatas=batch_meta)
        total_ingested += count
        print(f"  Ingested batch {i // batch_size + 1}: {count} entries")

    print(f"Total ingested: {total_ingested}")
    print(f"Knowledge base size: {chroma.get_collection_count()}")


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "data/seed_logs.json"
    seed_knowledge_base(path)
